import sys
import asyncio

# Fix for Windows async compatibility
if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import DATABASE_URL

# ──────────────────────────────────────────
# Sync engine  (used by all existing routes)
# ──────────────────────────────────────────
engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ──────────────────────────────────────────
# Async engine  (used by AI chat router)
# ──────────────────────────────────────────
# psycopg v3 async driver needs a different dialect name
ASYNC_DATABASE_URL = DATABASE_URL.replace(
    "postgresql+psycopg://", "postgresql+psycopg_async://"
)

async_engine = create_async_engine(ASYNC_DATABASE_URL)

AsyncSessionLocal = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False
)


async def get_async_db():
    async with AsyncSessionLocal() as db:
        yield db


async def get_session_factory():
    return AsyncSessionLocal